// Chế độ cá nhân: chủ app tự tắt quảng cáo trên MÁY MÌNH (không ảnh hưởng người khác).
// Bật: chạm 7 lần liên tiếp vào chữ "Menu" ở đầu Menu → nhập mã. Chạm 7 lần lần nữa để tắt chế độ.
import { setPersonalMode, isPersonalMode } from './ads.js';
import { showToast } from './ui.js';

const SALT = 'spx-personal-v1:';
const CODE_HASH = '3f9e862c65780431d168e0060c68d0a672480f2d5006bc0f4e508accdcd06a96';

async function sha256Hex(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function verifyCode(code) {
  try { return (await sha256Hex(SALT + code)) === CODE_HASH; } catch (_) { return false; }
}

export function initPersonalMode() {
  const title = document.querySelector('#menuModal .modal-box-head h3');
  if (!title) return;
  let taps = 0;
  let timer = null;
  title.addEventListener('click', async () => {
    taps += 1;
    clearTimeout(timer);
    timer = setTimeout(() => { taps = 0; }, 3000);
    if (taps < 7) return;
    taps = 0;
    if (isPersonalMode()) {
      setPersonalMode(false);
      showToast('🔒 Đã tắt chế độ cá nhân — quảng cáo hiện lại khi mở app lần sau', 'info', 3500);
      return;
    }
    const entered = window.prompt('Nhập mã chế độ cá nhân:');
    if (entered === null) return;
    if (await verifyCode(entered.trim())) {
      setPersonalMode(true);
      showToast('🔓 Đã bật chế độ cá nhân — không quảng cáo trên máy này', 'success', 3500);
    } else {
      showToast('Sai mã', 'warning', 2000);
    }
  });
}
