// AdMob qua Capacitor. KHÔNG import '@capacitor-community/admob' (không có bundler
// nên trình duyệt/WebView không phân giải được). Lấy plugin từ window.Capacitor.Plugins.

// MÃ TEST CỦA GOOGLE
const BANNER_ID = 'ca-app-pub-3940256099942544/6300978111';
const INTERSTITIAL_ID = 'ca-app-pub-3940256099942544/1033173712';
const DEFAULT_BANNER_H = 60; // px — dùng khi plugin không báo chiều cao

// CÔNG TẮC TỔNG: đặt false để tắt toàn bộ quảng cáo (gửi được qua OTA, không cần APK mới)
const ADS_ENABLED = true;

// Quảng cáo toàn màn hình: không làm phiền người dùng (và tránh bị coi là spam / bấm nhầm)
const INTERSTITIAL_MIN_GAP_MS = 5 * 60 * 1000; // cách nhau tối thiểu 5 phút, tính cả từ lúc mở app
const INTERSTITIAL_MAX_PER_DAY = 6;
const INTERSTITIAL_KEY = 'spx-ads-interstitial';
const sessionStart = Date.now();

// CÔNG TẮC TỪ XA: sửa file ads.json ({"enabled": true/false}) trong repo spx-ota trên GitHub,
// áp dụng ở lần mở app kế tiếp — không cần build, không cần Termux.
const FLAG_URL = 'https://raw.githubusercontent.com/linhha9490-lang/spx-ota/main/ads.json';
const FLAG_KEY = 'spx-ads-flag';
let flagPromise = null;

/** Đọc công tắc từ xa (tối đa 3s). Không tải được → dùng giá trị lần trước; chưa từng có → bật. */
function remoteFlagEnabled() {
  if (!flagPromise) {
    flagPromise = (async () => {
      let enabled = true;
      try { if (localStorage.getItem(FLAG_KEY) === '0') enabled = false; } catch (_) { /* bỏ qua */ }
      try {
        const ctl = new AbortController();
        const timer = setTimeout(() => ctl.abort(), 3000);
        const res = await fetch(FLAG_URL + '?t=' + Date.now(), { cache: 'no-store', signal: ctl.signal });
        clearTimeout(timer);
        if (res.ok) {
          const d = await res.json();
          if (d && typeof d.enabled === 'boolean') {
            enabled = d.enabled;
            try { localStorage.setItem(FLAG_KEY, enabled ? '1' : '0'); } catch (_) { /* bỏ qua */ }
          }
        }
      } catch (_) { /* offline / bị chặn → dùng giá trị đã lưu */ }
      return enabled;
    })();
  }
  return flagPromise;
}

/** Banner là view NATIVE nên vẫn còn trên màn hình sau khi OTA tải lại trang → phải gỡ bằng tay. */
function hideNativeBanner(AdMob) {
  setAdHeight(0);
  try {
    const p = AdMob && AdMob.removeBanner && AdMob.removeBanner();
    if (p && p.catch) p.catch(() => {});
  } catch (_) { /* bỏ qua */ }
}

const dbg = (m) => { try { if (window.__adsDbg) window.__adsDbg(m); } catch (_) { /* bỏ qua */ } };

let initPromise = null;
let bannerShown = false;
let listenersAdded = false;

function isNative() {
  return !!(window.Capacitor && window.Capacitor.isNativePlatform());
}

function getAdMob() {
  return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.AdMob;
}

/** Chừa chỗ ở đáy màn hình cho banner: CSS dùng biến --ad-h (thanh nav, popup, toast...). */
function setAdHeight(px) {
  document.documentElement.style.setProperty('--ad-h', px + 'px');
}

/** Chuẩn hóa chiều cao plugin báo về (có thể là dp hoặc px thật) về CSS px. */
function normalizeHeight(h) {
  let v = Number(h);
  if (v > 150) v = v / (window.devicePixelRatio || 1);
  return v >= 30 && v <= 150 ? Math.round(v) : DEFAULT_BANNER_H;
}

function addBannerListeners(AdMob) {
  if (listenersAdded || typeof AdMob.addListener !== 'function') return;
  listenersAdded = true;
  try {
    AdMob.addListener('bannerAdSizeChanged', (info) => {
      dbg('size ' + JSON.stringify(info));
      if (bannerShown) setAdHeight(normalizeHeight(info && info.height));
    });
    AdMob.addListener('bannerAdLoaded', () => dbg('LOADED ✔'));
    AdMob.addListener('bannerAdFailedToLoad', (err) => { dbg('FAILED ' + JSON.stringify(err)); setAdHeight(0); });
  } catch (e) {
    console.warn('Không gắn được listener banner:', e);
  }
}

// CHẾ ĐỘ CÁ NHÂN: cờ lưu riêng trên từng máy (xem js/personal.js), bật thì không quảng cáo
const PERSONAL_KEY = 'spx-personal';

export function isPersonalMode() {
  try { return localStorage.getItem(PERSONAL_KEY) === '1'; } catch (_) { return false; }
}

function personalHide() {
  setAdHeight(0);
  try {
    const AdMob = getAdMob();
    const p = AdMob && AdMob.removeBanner && AdMob.removeBanner();
    if (p && p.catch) p.catch(() => {});
  } catch (_) { /* bỏ qua */ }
}

export function setPersonalMode(on) {
  try {
    if (on) localStorage.setItem(PERSONAL_KEY, '1');
    else localStorage.removeItem(PERSONAL_KEY);
  } catch (_) { /* bỏ qua */ }
  if (on) personalHide(); // gỡ banner đang hiện ngay lập tức
}

/** Khởi tạo AdMob đúng 1 lần. Trả về true nếu sẵn sàng. */
export function initAds() {
  if (isNative() && isPersonalMode()) { personalHide(); return Promise.resolve(false); }
  if (!isNative()) return Promise.resolve(false);
  if (!ADS_ENABLED) { hideNativeBanner(getAdMob()); return Promise.resolve(false); }
  if (!initPromise) {
    initPromise = (async () => {
      try {
        const AdMob = getAdMob();
        dbg('init…');
        if (!AdMob) throw new Error('Plugin AdMob chưa có trong bản build native');
        if (!(await remoteFlagEnabled())) {
          dbg('quảng cáo đang TẮT (ads.json)');
          hideNativeBanner(AdMob);
          return false;
        }
        await AdMob.initialize();
        dbg('init OK');
        console.log('AdMob đã sẵn sàng');
        return true;
      } catch (e) {
        console.warn('Lỗi khởi tạo AdMob:', e);
        dbg('init LỖI: ' + ((e && e.message) || e));
        initPromise = null;
        return false;
      }
    })();
  }
  return initPromise;
}

export async function showBanner() {
  if (bannerShown || !(await initAds())) return;
  try {
    const AdMob = getAdMob();
    addBannerListeners(AdMob);
    dbg('showBanner…');
    await AdMob.showBanner({
      adId: BANNER_ID,
      adSize: 'ADAPTIVE_BANNER',
      position: 'BOTTOM_CENTER',
      margin: 0,
    });
    bannerShown = true;
    dbg('showBanner OK');
    setAdHeight(DEFAULT_BANNER_H); // sự kiện bannerAdSizeChanged (nếu có) sẽ chỉnh lại cho đúng
  } catch (e) {
    console.warn('Lỗi hiển thị banner:', e);
    dbg('showBanner LỖI: ' + ((e && e.message) || e));
  }
}

function localDay() {
  const t = new Date();
  return t.getFullYear() + '-' + (t.getMonth() + 1) + '-' + t.getDate();
}

function readCap() {
  try {
    const d = JSON.parse(localStorage.getItem(INTERSTITIAL_KEY) || '{}');
    if (d && d.day === localDay()) return d;
  } catch (_) { /* bỏ qua */ }
  return { day: localDay(), count: 0, last: 0 };
}

function writeCap(d) {
  try { localStorage.setItem(INTERSTITIAL_KEY, JSON.stringify(d)); } catch (_) { /* bỏ qua */ }
}

export async function showInterstitial() {
  if (!ADS_ENABLED) return;
  const cap = readCap();
  const now = Date.now();
  if (cap.count >= INTERSTITIAL_MAX_PER_DAY) return;
  if (now - Math.max(cap.last, sessionStart) < INTERSTITIAL_MIN_GAP_MS) return;
  if (!(await initAds())) return;
  try {
    const AdMob = getAdMob();
    await AdMob.prepareInterstitial({ adId: INTERSTITIAL_ID });
    await AdMob.showInterstitial();
    cap.count += 1;
    cap.last = now;
    writeCap(cap);
  } catch (e) {
    console.warn('Lỗi hiển thị interstitial:', e);
  }
}
