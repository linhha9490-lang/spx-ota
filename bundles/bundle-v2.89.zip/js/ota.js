// OTA - 3 link fallback, trả về 'error' khi tất cả fail để user biết
const OTA_URLS = [
  'https://raw.githubusercontent.com/linhha9490-lang/spx-ota/main/version.json',
  'https://linhha9490-lang.github.io/spx-ota/version.json',
  'https://cdn.jsdelivr.net/gh/linhha9490-lang/spx-ota@main/version.json'
];

export function isNativeApp() {
  return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
}

function updater() {
  return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater;
}

export function parseVersion(v) {
  const m = /(\d+)\.(\d+)(?:\.(\d+))?/.exec(String(v == null ? '' : v));
  return m ? [Number(m[1]), Number(m[2]), Number(m[3] || 0)] : null;
}

export function isNewer(a, b) {
  const x = parseVersion(a);
  const y = parseVersion(b);
  if (!x || !y) return false;
  for (let i = 0; i < 3; i++) {
    if (x[i] !== y[i]) return x[i] > y[i];
  }
  return false;
}

async function listBundles(U) {
  try {
    const r = await U.list();
    return (r && r.bundles) || [];
  } catch (_) {
    return [];
  }
}

export async function initOta() {
  const U = updater();
  if (!isNativeApp() || !U) return;
  try { await U.notifyAppReady(); } catch (e) { console.warn('[OTA] notifyAppReady lỗi:', e); return; }
  try {
    const cur = await U.current();
    const curId = cur && cur.bundle && cur.bundle.id;
    for (const b of await listBundles(U)) {
      if (b.status === 'success' && b.id !== curId) await U.delete({ id: b.id });
    }
  } catch (e) { console.warn('[OTA] Dọn bản cũ lỗi:', e); }
}

export async function checkOta(currentVersion) {
  let data = null;
  const errors = [];
  for (const url of OTA_URLS) {
    try {
      const res = await fetch(url + '?t=' + Date.now(), { cache: 'no-store' });
      if (res.ok) {
        const d = await res.json();
        if (d && d.version) { data = d; console.log('[OTA] OK:', url); break; }
      }
      errors.push(url + ': HTTP ' + res.status);
    } catch (err) { errors.push(url + ': ' + err.message); }
  }
  if (!data) {
    console.warn('[OTA] Tất cả link fail:\n' + errors.join('\n'));
    return { state: 'error', reason: errors.join('\n'), version: currentVersion };
  }
  if (!isNewer(data.version, currentVersion)) return { state: 'same', version: data.version };
  if (!data.bundle) {
    return { state: 'error', reason: 'Version ' + data.version + ' nhưng thiếu link tải bundle', version: data.version };
  }
  const U = updater();
  if (U) {
    const bad = (await listBundles(U)).some((b) => b.version === data.version && b.status === 'error');
    if (bad) return { state: 'same', version: data.version };
  }
  return { state: 'newer', version: data.version, bundle: data.bundle };
}

let inflight = null;
let inflightVersion = null;

export function prepareOta(info) {
  if (inflight && inflightVersion === info.version) return inflight;
  inflightVersion = info.version;
  inflight = (async () => {
    const U = updater();
    if (!U) throw new Error('Plugin CapacitorUpdater chưa có');
    const existing = (await listBundles(U)).find((b) => b.version === info.version && b.status !== 'error');
    let id = existing ? existing.id : null;
    if (!id) {
      const b = await U.download({ url: info.bundle, version: info.version });
      id = b.id;
    }
    await U.next({ id });
    return { version: info.version, id };
  })();
  inflight.catch(() => { inflight = null; inflightVersion = null; });
  return inflight;
}

export async function applyOta(info) {
  const p = await prepareOta(info);
  await updater().set({ id: p.id });
}
