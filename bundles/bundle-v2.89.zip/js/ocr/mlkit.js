// OCR bằng Google ML Kit — CHỈ trong app Android (qua plugin @capacitor-mlkit/text-recognition).
// KHÔNG import plugin trực tiếp (không có bundler): lấy qua window.Capacitor.Plugins, giống ads.js.
// Mọi lỗi / không có plugin / bị tắt → trả null để pipeline tự dùng Tesseract như cũ.
import { isNativeApp } from '../ota.js';
import { showToast } from '../ui.js';

const KEY = 'spx-mlkit';
const MAX_SIDE = 2400;      // ML Kit không cần ảnh quá lớn (ký tự ≥ 16–24px là đủ)
const TIMEOUT_MS = 20000;

function plugin(name) {
  return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins[name];
}

export function isMlKitAvailable() {
  return isNativeApp() && !!plugin('TextRecognition') && !!plugin('Filesystem');
}

/** Mặc định BẬT (trong app Android có plugin). Người dùng tắt được ở Menu. */
export function isMlKitEnabled() {
  if (!isMlKitAvailable()) return false;
  try { return localStorage.getItem(KEY) !== 'off'; } catch (_) { return true; }
}

export function setMlKitEnabled(on) {
  try { localStorage.setItem(KEY, on ? 'on' : 'off'); } catch (_) { /* bỏ qua */ }
}

/**
 * Ghép lại chữ theo HÀNG nhìn thấy trên màn hình (nhãn + con số cùng hàng nằm trên 1 dòng),
 * giống cách Tesseract trả về mà parser đang dùng. ML Kit mặc định tách nhãn/số thành các khối riêng.
 */
export function rowsToText(res) {
  const els = [];
  for (const b of (res && res.blocks) || []) {
    for (const l of b.lines || []) {
      for (const e of l.elements || []) {
        const bb = e && e.boundingBox;
        if (!bb || !e.text) continue;
        els.push({ t: e.text, l: bb.left, r: bb.right, cy: (bb.top + bb.bottom) / 2, h: Math.max(1, bb.bottom - bb.top) });
      }
    }
  }
  if (!els.length) return (res && res.text) || '';
  const hs = els.map((e) => e.h).sort((a, b) => a - b);
  const medH = hs[hs.length >> 1];
  els.sort((a, b) => a.cy - b.cy);
  const rows = [];
  for (const e of els) {
    const row = rows[rows.length - 1];
    if (row && Math.abs(e.cy - row.cy) <= medH * 0.6) {
      row.items.push(e);
      row.cy = row.items.reduce((s, x) => s + x.cy, 0) / row.items.length;
    } else {
      rows.push({ cy: e.cy, items: [e] });
    }
  }
  return rows.map((row) => {
    row.items.sort((a, b) => a.l - b.l);
    let line = '';
    row.items.forEach((it, i) => {
      if (i > 0) line += it.l - row.items[i - 1].r > medH * 2 ? '  ' : ' ';
      line += it.t;
    });
    return line;
  }).join('\n');
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result).split(',')[1] || '');
    fr.onerror = () => reject(fr.error || new Error('Không đọc được ảnh'));
    fr.readAsDataURL(blob);
  });
}

/** Thu nhỏ ảnh quá lớn (ảnh chụp từ camera) cho nhanh; ảnh chụp màn hình thường giữ nguyên. */
async function prepareBlob(file) {
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
    if (scale >= 1 && file.size < 4000000) { if (bmp.close) bmp.close(); return file; }
    const w = Math.round(bmp.width * scale);
    const h = Math.round(bmp.height * scale);
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    canvas.getContext('2d').drawImage(bmp, 0, 0, w, h);
    if (bmp.close) bmp.close();
    return await new Promise((res, rej) => canvas.toBlob((b) => (b ? res(b) : rej(new Error('toBlob'))), 'image/jpeg', 0.92));
  } catch (_) {
    return file;
  }
}

/**
 * Nhận dạng chữ bằng ML Kit. Trả về { rows, plain } hoặc null (→ dùng Tesseract).
 *  - rows: chữ ghép theo hàng (ưu tiên)   - plain: chữ nguyên bản của ML Kit (dự phòng)
 */
export async function mlkitRecognize(file) {
  if (!isMlKitEnabled()) return null;
  const TR = plugin('TextRecognition');
  const FS = plugin('Filesystem');
  const name = 'mlkit_' + Date.now() + '_' + Math.floor(Math.random() * 1e6) + '.jpg';
  let wrote = false;
  try {
    const data = await blobToBase64(await prepareBlob(file));
    const w = await FS.writeFile({ path: name, data, directory: 'CACHE' });
    wrote = true;
    const res = await Promise.race([
      TR.processImage({ path: w.uri, script: 'LATIN' }),
      new Promise((_, rej) => setTimeout(() => rej(new Error('ML Kit quá thời gian')), TIMEOUT_MS)),
    ]);
    const rows = rowsToText(res);
    const plain = (res && res.text) || '';
    if (!rows.trim() && !plain.trim()) return null;
    return { rows, plain };
  } catch (e) {
    console.warn('[MLKit] Lỗi, dùng Tesseract:', e);
    return null;
  } finally {
    if (wrote) {
      try { const p = FS.deleteFile({ path: name, directory: 'CACHE' }); if (p && p.catch) p.catch(() => {}); } catch (_) { /* bỏ qua */ }
    }
  }
}

/** Thêm mục "Quét ML Kit: BẬT/TẮT" vào Menu (chỉ hiện trong app Android có plugin). */
export function initMlKitMenu() {
  if (!isMlKitAvailable() || document.getElementById('menuMlKitTitle')) return;
  const anchor = document.getElementById('menuAutoSaveTitle');
  const after = anchor && anchor.closest('.menu-item');
  if (!after) return;
  const btn = document.createElement('button');
  btn.className = 'menu-item';
  btn.innerHTML =
    '<span class="menu-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
    '<rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/>' +
    '<path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/></svg></span>' +
    '<div class="menu-text"><div class="menu-title" id="menuMlKitTitle"></div><div class="menu-sub" id="menuMlKitSub"></div></div>';
  after.after(btn);
  const render = () => {
    const on = isMlKitEnabled();
    document.getElementById('menuMlKitTitle').textContent = 'Quét ML Kit: ' + (on ? 'BẬT' : 'TẮT');
    document.getElementById('menuMlKitSub').textContent = on
      ? 'Nhanh & chính xác hơn — tự dùng Tesseract nếu lỗi'
      : 'Chỉ dùng Tesseract (chậm hơn)';
  };
  btn.addEventListener('click', () => {
    setMlKitEnabled(!isMlKitEnabled());
    render();
    showToast(isMlKitEnabled() ? '✅ Đã bật quét ML Kit' : 'Đã tắt quét ML Kit', 'info', 2000);
  });
  render();
}
