// OTA - 3 link fallback, trả về 'error' khi tất cả fail để user biết
const OTA_URLS = [
  'https://raw.githubusercontent.com/linhha9490-lang/spx-ota/main/version.json',
  'https://linhha9490-lang.github.io/spx-ota/version.json',
  'https://cdn.jsdelivr.net/gh/linhha9490-lang/spx-ota@main/version.json'
];

// Chỉ nhận bundle nằm trong repo spx-ota (kể cả 2 mirror) — manifest lạ/hỏng không được trỏ ra nguồn khác.
const BUNDLE_URL_PREFIXES = [
  'https://raw.githubusercontent.com/linhha9490-lang/spx-ota/',
  'https://linhha9490-lang.github.io/spx-ota/',
  'https://cdn.jsdelivr.net/gh/linhha9490-lang/spx-ota/'
];

// Cấu hình (export để test chỉnh được).
export const otaConfig = {
  versionTimeoutMs: 8000,      // mỗi link version.json
  downloadTimeoutMs: 120000,   // tải + kiểm tra bundle
  retryDelayMs: 3000,          // nghỉ giữa 2 lần thử tải trong cùng 1 lượt
  attemptsPerPrepare: 2,
  maxFailsPerVersion: 2,       // số lượt thất bại tối đa cho 1 version trong 1 phiên chạy app
  requireSha256: true,         // Manifest thiếu SHA-256 bị từ chối; CI phải publish checksum trước
  maxBundleBytes: 50 * 1024 * 1024, // trần dung lượng bundle đọc vào RAM khi verifyBundle (bundle thật ~0,5 MB)
  initWaitMs: 5000             // prepareOta chờ initOta (notifyAppReady + dọn bản cũ) tối đa chừng này ms
};

const HEX64 = /^[0-9a-f]{64}$/i;
// Native (CapgoUpdater.finishDownload) tự tính SHA-256 của ZIP bằng chữ THƯỜNG rồi so bằng equals() — phân biệt hoa/thường —
// nên mọi checksum đưa cho plugin hoặc so với BundleInfo.checksum đều phải chuẩn hoá về chữ thường.
const normSha = (v) => String(v == null ? '' : v).toLowerCase();

// Chống vòng lặp "tải → áp dụng → tải lại": nếu bundle tự khai báo version khác với version trong manifest thì app sẽ
// luôn thấy "có bản mới". Đếm số lần đã áp dụng 1 version mà chưa thành công; từ lần thứ 3 thì thôi (reset khi thành công).
const TRIES_KEY = 'spx-ota-tries';
const MAX_APPLY_TRIES = 3;
function readTries() {
  try { const t = JSON.parse(localStorage.getItem(TRIES_KEY) || 'null'); return t && typeof t.v === 'string' ? t : null; } catch (_) { return null; }
}
function bumpTries(v) {
  const t = readTries();
  const n = t && t.v === v ? (t.n || 0) + 1 : 1;
  try { localStorage.setItem(TRIES_KEY, JSON.stringify({ v, n })); } catch (_) { /* bỏ qua */ }
}
/** Gọi khi app đã chạy đúng bản vừa áp dụng. */
export function clearApplyTries() {
  try { localStorage.removeItem(TRIES_KEY); } catch (_) { /* bỏ qua */ }
}

// ───────── Trạng thái cho UI ─────────
// checking | uptodate | available | downloading | downloaded | waiting | applying | failed
let _listener = null;
export function onOtaStatus(fn) { _listener = typeof fn === 'function' ? fn : null; }
function emit(state, extra) {
  if (!_listener) return;
  try { _listener({ state, ...(extra || {}) }); } catch (_) { /* UI lỗi không được làm hỏng OTA */ }
}

export function isNativeApp() {
  return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
}

function updater() {
  return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater;
}

export function parseVersion(v) {
  const m = /(\d+)\.(\d+)(?:\.(\d+))?/.exec(String(v == null ? '' : v));
  return m ? [Number(m[1]), Number(m[2]), Number(m[3] || 0)] : null;
}

export function isNewer(a, b) {
  const x = parseVersion(a);
  const y = parseVersion(b);
  if (!x || !y) return false;
  for (let i = 0; i < 3; i++) {
    if (x[i] !== y[i]) return x[i] > y[i];
  }
  return false;
}

// ───────── Tiện ích mạng ─────────
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function withTimeout(promise, ms, message) {
  let t;
  const timer = new Promise((_, rej) => { t = setTimeout(() => rej(new Error(message)), ms); });
  return Promise.race([promise, timer]).finally(() => clearTimeout(t));
}

/** fetch có timeout thật (huỷ yêu cầu) — dùng cho cả đọc thân phản hồi nếu truyền reader. */
async function fetchTimed(url, ms, reader) {
  const ctl = typeof AbortController === 'function' ? new AbortController() : null;
  const t = setTimeout(() => { if (ctl) ctl.abort(); }, ms);
  try {
    const run = (async () => {
      const res = await fetch(url, { cache: 'no-store', signal: ctl ? ctl.signal : undefined });
      return reader ? reader(res) : res;
    })();
    // Không có AbortController thì vẫn không treo vô hạn
    return await withTimeout(run, ms + 500, 'Quá thời gian chờ (' + Math.round(ms / 1000) + ' giây)');
  } finally {
    clearTimeout(t);
  }
}

/** Kiểm tra manifest; trả về lý do lỗi (string) hoặc null nếu hợp lệ. */
export function validateManifest(d) {
  if (!d || typeof d !== 'object') return 'manifest không phải object';
  // Manifest version phải đúng schema version.json của SPX (vX.Y), không chỉ chứa một cụm số bất kỳ.
  if (typeof d.version !== 'string' || !/^v\d+\.\d+$/.test(d.version)) return 'version không hợp lệ: ' + String(d.version);
  if (d.bundle != null) {
    if (typeof d.bundle !== 'string' || !BUNDLE_URL_PREFIXES.some((p) => d.bundle.startsWith(p))) {
      return 'bundle trỏ ra ngoài repo spx-ota';
    }
  }
  if (otaConfig.requireSha256 && (typeof d.sha256 !== 'string' || !/^[0-9a-f]{64}$/i.test(d.sha256))) return 'manifest thiếu hoặc sai định dạng sha256';
  if (d.sha256 != null && !/^[0-9a-f]{64}$/i.test(String(d.sha256))) return 'sha256 sai định dạng';
  if (d.size != null && !(Number.isInteger(d.size) && d.size > 0)) return 'size sai định dạng';
  return null;
}

// ───────── Kiểm tra bundle ZIP ─────────
/** Trả về danh sách tên file trong ZIP (đọc central directory) hoặc ném lỗi nếu không phải ZIP hợp lệ. */
export function zipEntryNames(buf) {
  const u8 = new Uint8Array(buf);
  if (u8.length < 22 || u8[0] !== 0x50 || u8[1] !== 0x4b || u8[2] !== 0x03 || u8[3] !== 0x04) {
    throw new Error('Không phải file ZIP');
  }
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  let eocd = -1;
  for (let i = u8.length - 22; i >= Math.max(0, u8.length - 22 - 65535); i--) {
    if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('ZIP bị cắt cụt (thiếu phần cuối)');
  const total = dv.getUint16(eocd + 10, true);
  let p = dv.getUint32(eocd + 16, true);
  const names = [];
  const dec = new TextDecoder('utf-8');
  for (let n = 0; n < total; n++) {
    if (p + 46 > u8.length || dv.getUint32(p, true) !== 0x02014b50) throw new Error('ZIP hỏng (central directory)');
    const nameLen = dv.getUint16(p + 28, true);
    const extraLen = dv.getUint16(p + 30, true);
    const cmtLen = dv.getUint16(p + 32, true);
    if (p + 46 + nameLen > u8.length) throw new Error('ZIP hỏng (tên file)');
    names.push(dec.decode(u8.subarray(p + 46, p + 46 + nameLen)));
    p += 46 + nameLen + extraLen + cmtLen;
  }
  return names;
}

export async function sha256Hex(buf) {
  const subtle = globalThis.crypto && globalThis.crypto.subtle;
  if (!subtle) throw new Error('Thiết bị không hỗ trợ SHA-256');
  const d = new Uint8Array(await subtle.digest('SHA-256', buf));
  return Array.from(d, (b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Tải thử bundle về RAM và kiểm tra TRƯỚC khi giao cho plugin: HTTP 200, đúng dung lượng/SHA-256 trong manifest,
 * đúng cấu trúc (có index.html ở gốc ZIP). Không đạt → ném lỗi → bundle không bao giờ được áp dụng.
 * SHA-256 là bắt buộc; manifest thiếu checksum bị từ chối trước khi tải.
 */
export async function verifyBundle(info) {
  if (!info.sha256 || !/^[0-9a-f]{64}$/i.test(String(info.sha256))) throw new Error('Manifest thiếu hoặc SHA-256 không hợp lệ');
  const cap = otaConfig.maxBundleBytes;
  const buf = await fetchTimed(info.bundle, otaConfig.downloadTimeoutMs, async (res) => {
    if (!res.ok) throw new Error('Tải bundle lỗi HTTP ' + res.status);
    // Có Content-Length thì từ chối trước khi nạp thân vào RAM
    const len = Number(res.headers && typeof res.headers.get === 'function' ? res.headers.get('content-length') : NaN);
    if (cap && Number.isFinite(len) && len > cap) throw new Error('Bundle quá lớn (' + len + ' > ' + cap + ' byte)');
    return res.arrayBuffer();
  });
  if (cap && buf.byteLength > cap) throw new Error('Bundle quá lớn (' + buf.byteLength + ' > ' + cap + ' byte)');
  if (info.size && buf.byteLength !== info.size) {
    throw new Error('Sai dung lượng bundle (' + buf.byteLength + ' ≠ ' + info.size + ')');
  }
  const names = zipEntryNames(buf);
  if (!names.includes('index.html')) throw new Error('Bundle thiếu index.html ở gốc');
  if (info.sha256) {
    const got = await sha256Hex(buf);
    if (got !== String(info.sha256).toLowerCase()) throw new Error('Sai checksum SHA-256 — bundle bị hỏng/không khớp manifest');
  } else {
    console.warn('[OTA] Manifest không có sha256 — chỉ kiểm tra cấu trúc ZIP.');
  }
}

async function listBundles(U) {
  try {
    const r = await U.list();
    return ((r && r.bundles) || []).filter(Boolean);
  } catch (_) {
    return [];
  }
}

/** Bundle đang chạy theo plugin (null nếu không đọc được). builtin có id 'builtin'. */
async function currentBundle(U) {
  try {
    const r = await U.current();
    return (r && r.bundle) || null;
  } catch (_) {
    return null;
  }
}

// Đối chiếu mã native @capgo/capacitor-updater 8.54.2:
//  • notifyAppReady → setSuccess(bản đang chạy): status 'success' nghĩa là bản đó đã BOOT và được xác nhận (khác chú thích trong
//    definitions.d.ts). Với autoDeletePrevious=true (mặc định) native tự xoá fallback cũ rồi lấy bản hiện tại làm fallback mới.
//  • delete() của native từ chối bản current / builtin / next, nhưng KHÔNG chặn xoá fallback thường → JS chỉ được dọn khi chắc chắn
//    bản đang chạy đã success (lúc đó fallback chính là bản đang chạy), nếu không sẽ xoá mất đường lùi.
let initDone = null;
export function initOta() {
  initDone = runInitOta();
  return initDone;
}
async function runInitOta() {
  const U = updater();
  if (!isNativeApp() || !U) return;
  try { await U.notifyAppReady(); } catch (e) { console.warn('[OTA] notifyAppReady lỗi:', e); return; }
  try {
    const cur = await currentBundle(U);
    if (!cur || !cur.id || cur.status !== 'success') {
      console.warn('[OTA] Bỏ qua dọn bản cũ: chưa xác định được bản đang chạy hoặc nó chưa được xác nhận success');
      return;
    }
    for (const b of await listBundles(U)) {
      if (b.status !== 'success' || b.id === cur.id) continue;
      // 1 bản không xoá được (vd đang là next) không được chặn việc dọn các bản còn lại
      try { await U.delete({ id: b.id }); } catch (e) { console.warn('[OTA] Không xoá được bản cũ', b.id, e); }
    }
  } catch (e) { console.warn('[OTA] Dọn bản cũ lỗi:', e); }
}

/** Chờ initOta xong (có trần thời gian) để prepareOta không chạy đua với bước dọn bản cũ. */
function waitForInit() {
  if (!initDone) return null;
  let t;
  const timeout = new Promise((r) => { t = setTimeout(r, otaConfig.initWaitMs); });
  return Promise.race([initDone, timeout]).finally(() => clearTimeout(t));
}

export async function checkOta(currentVersion) {
  emit('checking');
  let data = null;
  const errors = [];
  for (const url of OTA_URLS) {
    try {
      const d = await fetchTimed(url + '?t=' + Date.now(), otaConfig.versionTimeoutMs, async (res) => {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      });
      const bad = validateManifest(d);
      if (bad) { errors.push(url + ': ' + bad); continue; }
      data = d;
      console.log('[OTA] OK:', url);
      break;
    } catch (err) { errors.push(url + ': ' + (err && err.message)); }
  }
  if (!data) {
    console.warn('[OTA] Tất cả link fail:\n' + errors.join('\n'));
    emit('failed', { reason: 'Không kết nối được server cập nhật', silent: true });
    return { state: 'error', reason: errors.join('\n'), version: currentVersion };
  }
  if (!isNewer(data.version, currentVersion)) { emit('uptodate', { version: data.version }); return { state: 'same', version: data.version }; }
  if (!data.bundle) {
    emit('failed', { version: data.version, reason: 'Manifest thiếu link bundle' });
    return { state: 'error', reason: 'Version ' + data.version + ' nhưng thiếu link tải bundle', version: data.version };
  }
  const tries = readTries();
  if (tries && tries.v === data.version && tries.n >= MAX_APPLY_TRIES) {
    console.warn('[OTA] Bỏ qua ' + data.version + ': đã áp dụng ' + tries.n + ' lần mà app vẫn chưa chạy bản này.');
    return { state: 'same', version: data.version };
  }
  const U = updater();
  if (U) {
    const bad = (await listBundles(U)).some((b) => b.version === data.version && b.status === 'error');
    if (bad) return { state: 'same', version: data.version };
  }
  emit('available', { version: data.version });
  return { state: 'newer', version: data.version, bundle: data.bundle, sha256: data.sha256 || null, size: data.size || null };
}

let inflight = null;
let inflightKey = null;
const failCount = new Map();

export function prepareOta(info) {
  // Khoá cache gồm cả SHA-256: cùng version nhưng manifest đã đổi nội dung thì KHÔNG được trả kết quả của lượt trước.
  const key = info.version + '|' + normSha(info.sha256);
  if (inflight && inflightKey === key) return inflight;
  if ((failCount.get(info.version) || 0) >= otaConfig.maxFailsPerVersion) {
    return Promise.reject(new Error('Đã thử tải ' + info.version + ' nhiều lần không được — sẽ thử lại khi mở app lần sau'));
  }
  inflightKey = key;
  const p = (async () => {
    const U = updater();
    if (!U) throw new Error('Plugin CapacitorUpdater chưa có');
    if (!HEX64.test(String(info.sha256 == null ? '' : info.sha256))) throw new Error('Manifest thiếu hoặc SHA-256 không hợp lệ');
    const want = normSha(info.sha256);
    await waitForInit();
    const bundles = await listBundles(U);
    const cur = await currentBundle(U);
    const curId = cur && cur.id ? cur.id : null;
    const same = bundles.filter((b) => b.version === info.version);

    // Bằng chứng duy nhất để dùng lại 1 bundle đã có trên máy: BundleInfo.checksum (native lưu SHA-256 do CHÍNH NÓ TÍNH từ ZIP đã
    // tải, và chỉ lưu khi khớp giá trị mong đợi) trùng SHA-256 manifest hiện tại. Cùng version KHÔNG đủ: manifest có thể được
    // publish lại nội dung khác dưới cùng số version.
    const reusable = (b) => (b.status === 'success' || b.status === 'pending') && normSha(b.checksum) === want;

    // Bản đang chạy mang version này mà không khớp manifest → không xoá, không thay thế, báo lỗi rõ ràng.
    const running = curId ? same.find((b) => b.id === curId) : null;
    if (running && !reusable(running)) {
      throw new Error('Bundle đang chạy không khớp checksum manifest ' + info.version + ' — giữ nguyên, không xoá/thay thế');
    }

    const good = same.find(reusable);
    let id = good ? good.id : null;
    if (!id) {
      // Pending cũ không khớp: dọn để khỏi nhầm lẫn (best-effort). Native từ chối xoá bản next/current → không được làm hỏng
      // lượt tải; ta chỉ dùng id của bản mới đã xác minh và `next` sẽ trỏ sang bản đó. Không động tới success cũ (có thể là
      // fallback) — initOta dọn chúng sau khi notifyAppReady.
      for (const b of same) {
        if (b.status !== 'pending' || b.id === curId) continue;
        try { await U.delete({ id: b.id }); } catch (e) { console.warn('[OTA] Không xoá được pending cũ', b.id, e && e.message); }
      }
      emit('downloading', { version: info.version });
      let lastErr = null;
      for (let attempt = 1; attempt <= otaConfig.attemptsPerPrepare && !id; attempt++) {
        try {
          await verifyBundle(info);
          const dl = await withTimeout(
            U.download({ url: info.bundle, version: info.version, checksum: want }),
            otaConfig.downloadTimeoutMs, 'Tải bundle quá thời gian');
          if (!dl || !dl.id) throw new Error('Plugin không trả về id bundle');
          id = dl.id;
        } catch (e) {
          lastErr = e;
          console.warn('[OTA] Tải lần ' + attempt + ' lỗi:', e && e.message);
          if (attempt < otaConfig.attemptsPerPrepare) await sleep(otaConfig.retryDelayMs);
        }
      }
      if (!id) throw lastErr || new Error('Tải bundle thất bại');
    }
    await U.next({ id });
    emit('downloaded', { version: info.version });
    return { version: info.version, id };
  })();
  inflight = p;
  p.catch((e) => {
    if (inflight === p) { inflight = null; inflightKey = null; }
    failCount.set(info.version, (failCount.get(info.version) || 0) + 1);
    emit('failed', { version: info.version, reason: (e && e.message) || String(e) });
  });
  return p;
}

export async function applyOta(info) {
  const p = await prepareOta(info);
  bumpTries(info.version);
  emit('applying', { version: info.version });
  await updater().set({ id: p.id });
}
