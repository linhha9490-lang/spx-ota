const _nf = new Intl.NumberFormat('vi-VN');
export const _fmt = n => _nf.format(n);

// ===== generateId không bao giờ trùng, tăng dần đơn điệu =====
let _lastId = 0;
export const generateId = () => {
  const base = Date.now() * 1000;
  if (base <= _lastId) {
    _lastId += 1;
  } else {
    _lastId = base + Math.floor(Math.random() * 1000);
  }
  return _lastId;
};

export const sanitizeInt = v => { const n = parseInt(v, 10); return Number.isFinite(n) && n > 0 ? n : 0; };
export const formatPts   = n => _fmt(Math.round(n)) + ' Điểm';

export function getTodayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function formatDateDisplay(iso) {
  if (!iso) return '';
  const p = iso.split('-');
  return p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : iso;
}

// ===== v42: Month picker helpers =====

/**
 * Trả về tháng hiện tại dạng ISO: "2026-10"
 */
export function getCurrentMonthIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

/**
 * Format tháng để hiển thị: "2026-10" → "Tháng 10/2026"
 */
export function formatMonthLabel(isoMonth) {
  if (!isoMonth || !/^\d{4}-\d{2}$/.test(isoMonth)) return '';
  const [y, m] = isoMonth.split('-');
  return `Tháng ${parseInt(m, 10)}/${y}`;
}

export function isValidIsoDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

export function debounce(fn, delay) {
  let t = null;
  return function (...args) {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), delay);
  };
}

// Escape chuỗi trước khi chèn vào innerHTML (tên file, thông báo lỗi... — mọi dữ liệu không phải số)
export function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}
