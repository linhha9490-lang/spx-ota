import { STORAGE_KEYS, WEIGHT_KEYS } from './config.js';
import { generateId, getCurrentMonthIso, getTodayIso, isValidIsoDate } from './utils.js';

export const state = {
  appData: { delivery: [], pickup: [], return: [] },

  // Lương theo tháng
  salaryByMonth: {},

  // Hạng thưởng theo tháng
  rankByMonth: {},

  region: 'mien',

  activeTab: 'overview',
  histFilter: 'all',
  overviewFilter: 'del',

  periodMode: 'month',
  currentMonth: getCurrentMonthIso(),
  currentDate: getTodayIso(),

  forceShowNuocRut: localStorage.getItem('spx_force_nuoc_rut') === '1',
  lastOcrImageDataUrl: '',
  isOcrScan: false
};

const SALARY_BY_MONTH_KEY = 'spx_salary_by_month';
const LEGACY_SALARY_KEY   = 'spx_manual_salary';
const LEGACY_POINTS_KEY   = 'spx_manual_points';

const RANK_BY_MONTH_KEY   = 'spx_rank_by_month';
const LEGACY_RANK_KEY     = 'spx_rank_bonus';
const LEGACY_RANK_NAME_KEY= 'spx_rank_name';

// ============ SAFE PARSE ============
/**
 * Parse localStorage an toàn — không crash khi data hỏng.
 * @param {string} key - tên key trong localStorage
 * @param {*} fallback - giá trị trả về nếu parse lỗi hoặc không có
 * @returns {*}
 */
function safeParseLocalStorage(key, fallback = null) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return (parsed === null || parsed === undefined) ? fallback : parsed;
  } catch (e) {
    console.warn('[Storage] Parse lỗi key:', key, e.message);
    return fallback;
  }
}

/**
 * Lấy giá trị localStorage dạng số an toàn.
 */
function safeParseNumber(key, fallback = 0) {
  try {
    const raw = localStorage.getItem(key);
    if (raw === null || raw === '') return fallback;
    const n = parseFloat(raw);
    return Number.isFinite(n) ? n : fallback;
  } catch {
    return fallback;
  }
}

/**
 * Lấy string localStorage an toàn — nếu parse ra không phải string thì trả fallback.
 */
function safeParseString(key, fallback = '') {
  try {
    const raw = localStorage.getItem(key);
    return typeof raw === 'string' ? raw : fallback;
  } catch {
    return fallback;
  }
}
// ============ /SAFE PARSE ============

// ============ SANITIZE WEIGHTS ============
/**
 * Chuẩn hóa object weights — đảm bảo có đủ 8 key, đều là số nguyên ≥ 0.
 * Tránh crash khi import file backup cũ thiếu key / sai type.
 *
 * @param {*} w - object weights thô từ bất kỳ nguồn nào
 * @returns {Object} object weights có đủ 8 key hợp lệ
 */
function sanitizeWeights(w) {
  const out = {};
  const safe = (w && typeof w === 'object') ? w : {};
  WEIGHT_KEYS.forEach(k => {
    const v = parseInt(safe[k], 10);
    out[k] = (Number.isFinite(v) && v > 0) ? v : 0;
  });
  return out;
}
// ============ /SANITIZE WEIGHTS ============

export function sanitizeRecords(arr) {
  if (!Array.isArray(arr)) return [];
  const seen = new Set();
  const out = [];
  for (const r of arr) {
    if (!r || typeof r !== 'object' || !isValidIsoDate(r.date)) continue;
    let id = Number.isFinite(r.id) ? r.id : generateId();
    while (seen.has(id)) id = generateId();   // id trùng sẽ làm Sửa/Xóa nhầm bản ghi
    seen.add(id);
    out.push({ id, date: r.date, weights: sanitizeWeights(r.weights) });
  }
  return out;
}

// ============ SALARY BY MONTH ============
export function persistSalaryByMonth() {
  try {
    localStorage.setItem(SALARY_BY_MONTH_KEY, JSON.stringify(state.salaryByMonth));
  } catch (e) {
    console.warn('[Storage] Không ghi được salaryByMonth:', e);
  }
}

export function getSalaryConfig(monthIso) {
  const m = monthIso || state.currentMonth || getCurrentMonthIso();
  const cfg = state.salaryByMonth[m];
  if (cfg && typeof cfg === 'object') {
    return {
      base:   Number(cfg.base)   || 0,
      buuCuc: Number(cfg.buuCuc) || 0,
      taiXe:  Number(cfg.taiXe)  || 0
    };
  }
  return { base: 0, buuCuc: 0, taiXe: 0 };
}

export function setSalaryConfig(monthIso, config) {
  const m = monthIso || state.currentMonth || getCurrentMonthIso();
  state.salaryByMonth[m] = {
    base:   Number(config.base)   || 0,
    buuCuc: Number(config.buuCuc) || 0,
    taiXe:  Number(config.taiXe)  || 0
  };
  persistSalaryByMonth();
}

export function hasSalaryConfig(monthIso) {
  const m = monthIso || state.currentMonth || getCurrentMonthIso();
  return Boolean(state.salaryByMonth[m]);
}

function loadSalaryByMonth() {
  // 1. Thử đọc cấu trúc mới
  const parsed = safeParseLocalStorage(SALARY_BY_MONTH_KEY, null);
  if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
    state.salaryByMonth = parsed;
    return;
  }

  // 2. Migration từ data cũ (chạy 1 lần duy nhất)
  const oldSalary = safeParseNumber(LEGACY_SALARY_KEY, 0);
  const oldPts = safeParseLocalStorage(LEGACY_POINTS_KEY, {});
  const oldBuuCuc = Number(oldPts?.buuCuc) || 0;
  const oldTaiXe  = Number(oldPts?.taiXe)  || 0;

  if (oldSalary > 0 || oldBuuCuc > 0 || oldTaiXe > 0) {
    const m = state.currentMonth || getCurrentMonthIso();
    state.salaryByMonth = {
      [m]: { base: oldSalary, buuCuc: oldBuuCuc, taiXe: oldTaiXe }
    };
    persistSalaryByMonth();
    try {
      localStorage.removeItem(LEGACY_SALARY_KEY);
      localStorage.removeItem(LEGACY_POINTS_KEY);
    } catch {}
    console.log('[Migration] Đã chuyển config lương cũ vào tháng', m);
  }
}
// ============ /SALARY BY MONTH ============

// ============ RANK BY MONTH ============
export function persistRankByMonth() {
  try {
    localStorage.setItem(RANK_BY_MONTH_KEY, JSON.stringify(state.rankByMonth));
  } catch (e) {
    console.warn('[Storage] Không ghi được rankByMonth:', e);
  }
}

export function getRankConfig(monthIso) {
  const m = monthIso || state.currentMonth || getCurrentMonthIso();
  const cfg = state.rankByMonth[m];
  if (cfg && typeof cfg === 'object' && cfg.name) {
    return {
      name:  String(cfg.name),
      bonus: Number(cfg.bonus) || 0
    };
  }
  return { name: 'none', bonus: 0 };
}

export function setRankConfig(monthIso, config) {
  const m = monthIso || state.currentMonth || getCurrentMonthIso();
  const name  = config.name || 'none';
  const bonus = Number(config.bonus) || 0;

  if (name === 'none') {
    delete state.rankByMonth[m];
  } else {
    state.rankByMonth[m] = { name, bonus };
  }
  persistRankByMonth();
}

function loadRankByMonth() {
  const parsed = safeParseLocalStorage(RANK_BY_MONTH_KEY, null);
  if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
    state.rankByMonth = parsed;
    return;
  }

  // Migration từ data cũ
  const oldBonus = safeParseNumber(LEGACY_RANK_KEY, 0);
  const oldName  = safeParseString(LEGACY_RANK_NAME_KEY, 'none');

  if (oldName !== 'none' && oldBonus > 0) {
    const m = state.currentMonth || getCurrentMonthIso();
    state.rankByMonth = {
      [m]: { name: oldName, bonus: oldBonus }
    };
    persistRankByMonth();
    try {
      localStorage.removeItem(LEGACY_RANK_KEY);
      localStorage.removeItem(LEGACY_RANK_NAME_KEY);
    } catch {}
    console.log('[Migration] Đã chuyển hạng thưởng cũ vào tháng', m);
  }
}
// ============ /RANK BY MONTH ============

// ============ LOAD STATE (HARDENED) ============
export function loadState() {
  // 1. Load records — an toàn với data hỏng
  let d = safeParseLocalStorage(STORAGE_KEYS.records, null);

  // Nếu không có records → thử vault
  if (!d || (!d.delivery && !d.pickup && !d.return)) {
    const vaultData = safeParseLocalStorage(STORAGE_KEYS.vault, null);
    if (vaultData) {
      d = vaultData;
      console.log('[loadState] Phục hồi từ vault');
    }
  }

  // Nếu vẫn không có → khởi tạo rỗng
  if (!d || typeof d !== 'object') {
    d = { delivery: [], pickup: [], return: [] };
  }

  // Sanitize từng loại (sanitize cả weights)
  state.appData = {
    delivery: sanitizeRecords(d.delivery),
    pickup:   sanitizeRecords(d.pickup),
    return:   sanitizeRecords(d.return)
  };

  // 2. Period mode — chế độ "ngày" đã bỏ khỏi UI; ép về 'month' để máy còn giá trị 'day'
  //    từ bản cũ không bị kẹt ở chế độ lọc theo ngày mà không có nút để thoát.
  state.periodMode = 'month';
  try { localStorage.setItem('spx_period_mode', 'month'); } catch {}

  // 3. currentMonth — validate format
  const savedMonth = safeParseString('spx_current_month', '');
  if (/^\d{4}-\d{2}$/.test(savedMonth)) {
    state.currentMonth = savedMonth;
  } else {
    state.currentMonth = getCurrentMonthIso();
  }

  // 4. currentDate — validate format
  const savedDate = safeParseString('spx_current_date', '');
  if (/^\d{4}-\d{2}-\d{2}$/.test(savedDate)) {
    state.currentDate = savedDate;
  } else {
    state.currentDate = getTodayIso();
  }

  // 5. Salary config (số công được derive từ tháng trong render.js — không lưu state nữa)
  loadSalaryByMonth();

  // 6. Rank config
  loadRankByMonth();

  // 7. Region
  const reg = safeParseString('spx_region', 'mien');
  state.region = (reg === 'hcm_hn' || reg === 'mien') ? reg : 'mien';
}
// ============ /LOAD STATE ============

// Chỉ ghi khi dữ liệu THỰC SỰ đổi (1 lần stringify/lần gọi, thay vì 3 lần + 2 lần ghi mỗi render).
// Trả về true nếu có thay đổi so với lần ghi trước (dùng để kích hoạt auto-backup cloud).
let _lastSerialized = null;
export function persistData() {
  let json;
  try { json = JSON.stringify(state.appData); } catch { return false; }
  if (json === _lastSerialized) return false;
  // Lần ghi đầu tiên sau khi mở app trả về false (cố ý): mở app không được kích hoạt auto-backup Cloud.
  const first = _lastSerialized === null;
  try {
    localStorage.setItem(STORAGE_KEYS.records, json);
    const { delivery, pickup, return: ret } = state.appData;
    if (delivery.length + pickup.length + ret.length > 0) {
      localStorage.setItem(STORAGE_KEYS.vault, json);
    }
    _lastSerialized = json;
    return !first;
  } catch (e) {
    console.warn('[Storage] Không ghi được records:', e);
    window.dispatchEvent(new CustomEvent('spx:storage-error', { detail: e }));
    return false;
  }
}

export function persistSettings() {
  try {
    localStorage.setItem('spx_region', state.region);
  } catch {}
}

export function persistPeriodState() {
  try {
    localStorage.setItem('spx_period_mode',  state.periodMode);
    localStorage.setItem('spx_current_month', state.currentMonth);
    localStorage.setItem('spx_current_date',  state.currentDate);
  } catch {}
}
